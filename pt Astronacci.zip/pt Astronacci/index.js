const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const passport = require('passport');
const dotenv = require('dotenv');
const authRoutes = require('./routes/auth');

dotenv.config();

require('./utils/passportConfig')(passport);

const app = express();
app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

app.use('/', authRoutes);

const isLoggedIn = (req, res, next) => {
  if (req.isAuthenticated()) return next();
  res.redirect('/login');
};

app.get('/dashboard', isLoggedIn, (req, res) => {
  res.render('dashboard', { user: req.user });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server on http://localhost:${PORT}`));

const db = require('./db');

db.getConnection()
  .then(() => console.log('✅ Database terkoneksi'))
  .catch(err => console.error('❌ Gagal koneksi ke DB:', err.message));

const contentRoutes = require('./routes/content');
app.use('/', contentRoutes);

const adminRoutes = require('./routes/admin');
app.use('/', adminRoutes);

app.use(cors());
app.use(express.json());

app.use('/api/buku', require('./routes/bukuroutes'));
app.use('/api/soal', require('./routes/soalroutes'));
app.use('/api/riwayat', require('./routes/riwayatroutes'));

app.listen(3000, () => console.log('✅ Server running on http://localhost:3000'));

app.get('/dashboard', isLoggedIn, (req, res) => {
  res.render('dashboard', { user: req.user });
});