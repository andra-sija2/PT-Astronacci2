const db = require('../elearning');

exports.getAll = async (req, res) => {
  const [data] = await db.query("SELECT * FROM buku");
  res.json(data);
};

exports.create = async (req, res) => {
  const { judul, deskripsi, penulis, tahun } = req.body;
  await db.query("INSERT INTO buku (judul, deskripsi, penulis, tahun) VALUES (?, ?, ?, ?)", [judul, deskripsi, penulis, tahun]);
  res.json({ status: 'success' });
};

exports.update = async (req, res) => {
  const { id } = req.params;
  const { judul, deskripsi, penulis, tahun } = req.body;
  await db.query("UPDATE buku SET judul=?, deskripsi=?, penulis=?, tahun=? WHERE id=?", [judul, deskripsi, penulis, tahun, id]);
  res.json({ status: 'updated' });
};

exports.delete = async (req, res) => {
  await db.query("DELETE FROM buku WHERE id=?", [req.params.id]);
  res.json({ status: 'deleted' });
};
