const db = require('../elearning');

exports.simpanRiwayat = async (req, res) => {
  const { user_id, total_soal, benar } = req.body;
  const skor = Math.round((benar / total_soal) * 100);

  await db.query("INSERT INTO riwayat_soal (user_id, total_soal, benar, skor) VALUES (?, ?, ?, ?)",
    [user_id, total_soal, benar, skor]);

  res.json({ status: 'success', skor });
};

exports.getRiwayatAll = async (req, res) => {
  const [data] = await db.query(`
    SELECT r.*, u.nama, u.email
    FROM riwayat_soal r
    JOIN users u ON r.user_id = u.id
    ORDER BY r.waktu DESC
  `);

  res.json(data);
};

exports.simpanRiwayat = async (req, res) => {
  const { user_id, total_soal, benar, topik } = req.body;
  const skor = Math.round((benar / total_soal) * 100);

  await db.query(`
    INSERT INTO riwayat_soal (user_id, total_soal, benar, skor, topik)
    VALUES (?, ?, ?, ?, ?)`, [user_id, total_soal, benar, skor, topik]);

  res.json({ status: 'success', skor });
};

exports.getSkorByUserGroupedByTopik = async (req, res) => {
  const user_id = req.params.id;
  const [data] = await db.query(`
    SELECT topik, AVG(skor) as rata_rata
    FROM riwayat_soal
    WHERE user_id = ?
    GROUP BY topik
  `, [user_id]);

  res.json(data);
};