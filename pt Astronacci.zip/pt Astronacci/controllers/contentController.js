const db = require('../elearning');

exports.dashboard = async (req, res) => {
  if (!req.session.user) return res.redirect('/auth/login');
  const membership = req.session.user.membership;

  const limit = membership === 'A' ? 3 : membership === 'B' ? 10 : 9999;

  const [artikel] = await db.query(`SELECT * FROM artikel LIMIT ?`, [limit]);
  const [video] = await db.query(`SELECT * FROM video LIMIT ?`, [limit]);

  res.render('dashboard', {
    user: req.session.user,
    artikel,
    video
  });
};

const Article = require('../models/Article');
const Video = require('../models/Video');

const getArticles = async (req, res) => {
  const limit = req.contentLimit;
  const articles = await Article.find().limit(limit);
  res.render('articles', { articles });
};

const getVideos = async (req, res) => {
  const limit = req.contentLimit;
  const videos = await Video.find().limit(limit);
  res.render('videos', { videos });
};

const expired = new Date(req.session.user.expired_at);
if (expired < new Date()) {
  return res.send("Akses dibatasi. Membership Anda telah expired.");
}

module.exports = {
  getArticles,
  getVideos
};
