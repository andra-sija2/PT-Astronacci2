const db = require('../elearning');
const bcrypt = require('bcrypt');

exports.register = async (req, res) => {
  const { nama, email, password, role } = req.body;

  const [cek] = await db.query("SELECT * FROM users WHERE email = ?", [email]);
  if (cek.length > 0) return res.status(400).json({ status: 'error', message: 'Email sudah digunakan' });

  const hashed = await bcrypt.hash(password, 10);
  await db.query("INSERT INTO users (nama, email, password, role) VALUES (?, ?, ?, ?)", [nama, email, hashed, role]);

  res.json({ status: 'success' });
};

exports.login = async (req, res) => {
  const { email, password } = req.body;
  const [rows] = await db.query("SELECT * FROM users WHERE email = ?", [email]);
  if (rows.length === 0) return res.status(400).json({ status: 'error', message: 'Email tidak ditemukan' });

  const user = rows[0];
  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(400).json({ status: 'error', message: 'Password salah' });

  delete user.password;
  res.json({ status: 'success', user });
};

exports.list = async (req, res) => {
  const [rows] = await db.query("SELECT id, nama, email, role FROM users");
  res.json(rows);
};

exports.getAllSiswa = async (req, res) => {
  const [rows] = await db.query(`SELECT id, nama, email FROM users WHERE role = 'siswa'`);
  res.json(rows);
};