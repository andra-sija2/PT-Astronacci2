const db = require('../elearning');
const moment = require('moment');

exports.dashboard = async (req, res) => {
  const [users] = await db.query(`SELECT * FROM users`);
  const [transaksi] = await db.query(`
    SELECT t.*, u.nama, u.email FROM transactions t 
    JOIN users u ON t.user_id = u.id
    ORDER BY t.created_at DESC
  `);

  res.render('admin/admin-dashboard', { users, transaksi });
};

exports.upgradeManual = async (req, res) => {
  const { id } = req.params;
  const { membership } = req.body;

  const expired = new Date();
  expired.setDate(expired.getDate() + 30);

  await db.query(`
    UPDATE users SET membership = ?, expired_at = ? WHERE id = ?
  `, [membership, expired, id]);

  res.redirect('/admin/dashboard');
};

exports.viewRiwayat = async (req, res) => {
  const [rows] = await db.query(`
    SELECT r.id, u.nama, u.email, r.topik, r.total_soal, r.benar, r.skor, r.waktu
    FROM riwayat_soal r
    JOIN users u ON r.user_id = u.id
    ORDER BY r.waktu DESC
  `);

  res.render('admin/riwayat', {
    riwayat: rows,
    filter: { topik: '', tanggal_awal: '', tanggal_akhir: '' }
  });
};

exports.filterRiwayat = async (req, res) => {
  const { topik, tanggal_awal, tanggal_akhir } = req.body;
  let sql = `
    SELECT r.id, u.nama, u.email, r.topik, r.total_soal, r.benar, r.skor, r.waktu
    FROM riwayat_soal r
    JOIN users u ON r.user_id = u.id
    WHERE 1=1
  `;
  const params = [];

  if (topik) {
    sql += ` AND r.topik = ?`;
    params.push(topik);
  }

  if (tanggal_awal && tanggal_akhir) {
    sql += ` AND DATE(r.waktu) BETWEEN ? AND ?`;
    params.push(tanggal_awal, tanggal_akhir);
  }

  sql += ' ORDER BY r.waktu DESC';

  const [rows] = await db.query(sql, params);

  res.render('admin/riwayat', {
    riwayat: rows,
    filter: { topik, tanggal_awal, tanggal_akhir }
  });
};

exports.getRiwayatFiltered = async (req, res) => {
  const { topik, tanggal_awal, tanggal_akhir } = req.query;

  let sql = `
    SELECT r.id, u.nama, u.email, r.topik, r.total_soal, r.benar, r.skor, r.waktu
    FROM riwayat_soal r
    JOIN users u ON r.user_id = u.id
    WHERE 1=1
  `;
  const params = [];

  if (topik) {
    sql += ' AND r.topik = ?';
    params.push(topik);
  }

  if (tanggal_awal && tanggal_akhir) {
    sql += ' AND DATE(r.waktu) BETWEEN ? AND ?';
    params.push(tanggal_awal, tanggal_akhir);
  }

  sql += ' ORDER BY r.waktu DESC';

  const [rows] = await db.query(sql, params);
  res.json(rows);
};

exports.hasilUjian = async (req, res) => {
  const [data] = await db.query(`
    SELECT r.*, u.nama, u.email 
    FROM riwayat_soal r
    JOIN users u ON r.user_id = u.id
    ORDER BY r.waktu DESC
  `);

  res.render('admin/hasil_ujian', { data, filter: {} });
};

exports.filterHasilUjian = async (req, res) => {
  const { topik, tanggal_awal, tanggal_akhir } = req.body;
  let sql = `
    SELECT r.*, u.nama, u.email 
    FROM riwayat_soal r
    JOIN users u ON r.user_id = u.id
    WHERE 1=1
  `;
  const params = [];

  if (topik) {
    sql += ` AND r.topik = ?`;
    params.push(topik);
  }

  if (tanggal_awal && tanggal_akhir) {
    sql += ` AND DATE(r.waktu) BETWEEN ? AND ?`;
    params.push(tanggal_awal, tanggal_akhir);
  }

  sql += ` ORDER BY r.waktu DESC`;

  const [data] = await db.query(sql, params);
  res.render('admin/hasil_ujian', { data, filter: { topik, tanggal_awal, tanggal_akhir } });
};

exports.grafikUjian = async (req, res) => {
  const [rows] = await db.query(`
    SELECT topik, COUNT(*) AS jumlah, ROUND(AVG(skor), 1) AS rata_rata
    FROM riwayat_soal
    GROUP BY topik
  `);

  res.render('admin/grafik_ujian', { chartData: rows });
};