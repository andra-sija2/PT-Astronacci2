const db = require('../elearning');

exports.midtransCallback = async (req, res) => {
  const json = req.body;
  const order_id = json.order_id.replace('ORDER-', '');
  const status_code = json.transaction_status;

  if (status_code === 'settlement') {
    const [[trx]] = await db.query(`SELECT * FROM transactions WHERE id = ?`, [order_id]);

    await db.query(`UPDATE transactions SET status = 'paid' WHERE id = ?`, [order_id]);

    const expired = new Date();
    expired.setDate(expired.getDate() + 30);

    await db.query(`
      UPDATE users SET membership = ?, expired_at = ? WHERE id = ?
    `, [trx.membership_target, expired, trx.user_id]);

    console.log("Upgrade berhasil untuk user ID:", trx.user_id);
  }

  res.status(200).send('OK');
};