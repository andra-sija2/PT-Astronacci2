const db = require('../elearning');
const midtransClient = require('midtrans-client');

exports.showUpgrade = (req, res) => {
  res.render('member/upgrade', { user: req.session.user });
};

exports.requestUpgrade = async (req, res) => {
  const { membership_target } = req.body;
  const user = req.session.user;

  // Simpan transaksi ke DB
  const [result] = await db.query(`
    INSERT INTO transactions (user_id, membership_target)
    VALUES (?, ?)`, [user.id, membership_target]);

  const transaction_id = result.insertId;

  // Midtrans SNAP integration
  const snap = new midtransClient.Snap({
    isProduction: false,
    serverKey: 'YOUR_SERVER_KEY',
  });

  const parameter = {
    transaction_details: {
      order_id: `ORDER-${transaction_id}`,
      gross_amount: membership_target === 'B' ? 50000 : 100000, // harga B/C
    },
    customer_details: {
      first_name: user.nama,
      email: user.email,
    }
  };

  const snapRes = await snap.createTransaction(parameter);
  const payment_url = snapRes.redirect_url;

  // Update payment URL
  await db.query(`UPDATE transactions SET payment_url = ? WHERE id = ?`, [payment_url, transaction_id]);

  res.redirect(payment_url);
};
