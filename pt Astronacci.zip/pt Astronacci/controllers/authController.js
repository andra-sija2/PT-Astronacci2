const db = require('../elearning');
const bcrypt = require('bcrypt');

exports.showRegister = (req, res) => res.render('auth/register');
exports.showLogin = (req, res) => res.render('auth/login');

exports.handleRegister = async (req, res) => {
  const { nama, email, password, membership } = req.body;
  const hashed = await bcrypt.hash(password, 10);
  await db.query("INSERT INTO users (nama, email, password, membership) VALUES (?, ?, ?, ?)",
    [nama, email, hashed, membership || 'A']
  );
  res.redirect('/auth/login');
};

exports.handleLogin = async (req, res) => {
  const { email, password } = req.body;
  const [rows] = await db.query("SELECT * FROM users WHERE email = ?", [email]);
  if (rows.length === 0) return res.send("Email tidak ditemukan");
  const user = rows[0];
  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.send("Password salah");
  req.session.user = user;
  res.redirect('/dashboard');
};

exports.logout = (req, res) => {
  req.session.destroy();
  res.redirect('/auth/login');
};

const Article = require('../models/Article');
const Video = require('../models/Video');

const getArticles = async (req, res) => {
  const limit = req.contentLimit;
  const articles = await Article.find().limit(limit);
  res.render('articles', { articles });
};

const getVideos = async (req, res) => {
  const limit = req.contentLimit;
  const videos = await Video.find().limit(limit);
  res.render('videos', { videos });
};

const expiredAt = new Date();
expiredAt.setDate(expiredAt.getDate() + 30);

const today = new Date();
const expiredDate = new Date(user.expired_at);

if (expiredDate < today) {
  return res.send("Membership Anda sudah expired. Silakan hubungi admin untuk perpanjangan.");
}

await db.query(
  "INSERT INTO users (nama, email, password, membership, expired_at) VALUES (?, ?, ?, ?, ?)",
  [nama, email, hashed, membership || 'A', expiredAt]
);

module.exports = {
  getArticles,
  getVideos
};