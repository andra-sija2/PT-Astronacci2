const db = require('../elearning');

exports.getAll = async (req, res) => {
  const [data] = await db.query("SELECT * FROM soal");
  res.json(data);
};

exports.create = async (req, res) => {
  const { pertanyaan, pilihan_a, pilihan_b, pilihan_c, pilihan_d, kunci_jawaban } = req.body;
  await db.query("INSERT INTO soal (pertanyaan, pilihan_a, pilihan_b, pilihan_c, pilihan_d, kunci_jawaban) VALUES (?, ?, ?, ?, ?, ?)",
    [pertanyaan, pilihan_a, pilihan_b, pilihan_c, pilihan_d, kunci_jawaban]);
  res.json({ status: 'success' });
};

exports.delete = async (req, res) => {
  await db.query("DELETE FROM soal WHERE id=?", [req.params.id]);
  res.json({ status: 'deleted' });
};

exports.getSkorByUser = async (req, res) => {
  const user_id = req.params.id;
  const [rows] = await db.query(`
    SELECT skor, waktu FROM riwayat_soal
    WHERE user_id = ?
    ORDER BY waktu ASC
  `, [user_id]);

  res.json(rows);
};