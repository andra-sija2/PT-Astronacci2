const db = require('../elearnig');

exports.getAktifUjian = async (req, res) => {
  const topik = req.params.topik;
  const [rows] = await db.query(`
    SELECT * FROM jadwal_ujian
    WHERE topik = ? 
      AND NOW() BETWEEN tanggal_mulai AND tanggal_selesai
  `, [topik]);

  if (rows.length > 0) {
    res.json({ aktif: true });
  } else {
    res.json({ aktif: false });
  }
};