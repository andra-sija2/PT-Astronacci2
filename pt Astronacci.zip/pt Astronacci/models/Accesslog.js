const mongoose = require('mongoose');

const AccessLogSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  contentType: { type: String, enum: ['article', 'video'] },
  contentId: { type: mongoose.Schema.Types.ObjectId },
  accessedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('AccessLog', AccessLogSchema);