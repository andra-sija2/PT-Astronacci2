const limits = {
  A: 3,
  B: 10,
  C: Infinity
};

function limitContent(type) {
  return (req, res, next) => {
    const membership = req.user?.membership || 'A';
    req.contentLimit = limits[membership];
    req.contentType = type;
    next();
  };
}

module.exports = {
  limitContent
};