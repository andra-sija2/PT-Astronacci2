exports.cekExpired = (req, res, next) => {
  if (!req.session.user) return res.redirect('/auth/login');
  const expired = new Date(req.session.user.expired_at);
  if (expired < new Date()) return res.send("Membership Anda telah expired.");
  next();
};
