const AccessLog = require('../models/Accesslog');

const accessLimits = {
  A: 3,
  B: 10,
  C: Infinity
};

const checkAccessLimit = (type) => {
  return async (req, res, next) => {
    const user = req.user;
    const limit = accessLimits[user.membership];

    const accessCount = await AccessLog.countDocuments({
      userId: user._id,
      contentType: type
    });

    if (accessCount >= limit) {
      return res.send(`⚠️ You have reached your limit of ${limit} ${type}s as a ${user.membership} member.`);
    }

    next();
  };
};

module.exports = { checkAccessLimit };
