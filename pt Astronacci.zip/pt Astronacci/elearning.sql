CREATE DATABASE belajar_app;
USE belajar_app;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('siswa', 'admin') DEFAULT 'siswa',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE buku (
  id INT AUTO_INCREMENT PRIMARY KEY,
  judul VARCHAR(255) NOT NULL,
  deskripsi TEXT,
  penulis VARCHAR(100),
  tahun INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE artikel (
  id INT AUTO_INCREMENT PRIMARY KEY,
  judul VARCHAR(255),
  isi TEXT
);

CREATE TABLE video (
  id INT AUTO_INCREMENT PRIMARY KEY,
  judul VARCHAR(255),
  url TEXT
);

CREATE TABLE soal (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pertanyaan TEXT NOT NULL,
  jawaban TEXT NOT NULL,
  pilihan_a TEXT,
  pilihan_b TEXT,
  pilihan_c TEXT,
  pilihan_d TEXT,
  kunci_jawaban CHAR(1),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE chat_ai (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  pertanyaan TEXT,
  jawaban TEXT,
  waktu TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE sesi_belajar (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  durasi INT, -- dalam detik
  waktu TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS buku (
  id INT AUTO_INCREMENT PRIMARY KEY,
  judul VARCHAR(255),
  deskripsi TEXT,
  penulis VARCHAR(100),
  tahun INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS soal (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pertanyaan TEXT NOT NULL,
  pilihan_a TEXT,
  pilihan_b TEXT,
  pilihan_c TEXT,
  pilihan_d TEXT,
  kunci_jawaban CHAR(1),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE riwayat_soal (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  total_soal INT,
  benar INT,
  skor INT,
  waktu TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE jadwal_ujian (
  id INT AUTO_INCREMENT PRIMARY KEY,
  topik VARCHAR(100),
  tanggal_mulai DATETIME,
  tanggal_selesai DATETIME
);

CREATE TABLE transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  membership_target ENUM('B', 'C'),
  status ENUM('pending', 'paid', 'failed') DEFAULT 'pending',
  payment_url TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE soal ADD COLUMN topik VARCHAR(100) DEFAULT 'Umum';
ALTER TABLE riwayat_soal ADD COLUMN topik VARCHAR(100) DEFAULT 'Umum';
ALTER TABLE users ADD COLUMN expired_at DATE;
UPDATE users SET expired_at = DATE_ADD(NOW(), INTERVAL 30 DAY) WHERE id = 1;
INSERT INTO users (nama, email, password, membership, expired_at)
VALUES ('Admin', 'admin@example.com', '<hashed_password>', 'C', '2099-12-31');