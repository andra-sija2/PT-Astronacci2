import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function AdminRiwayat() {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3000/api/riwayat')
      .then(res => setData(res.data));
  }, []);

  return (
    <div style={{ padding: 20 }}>
      <h2>Riwayat Latihan Siswa</h2>
      <table border="1" cellPadding="8" cellSpacing="0">
        <thead>
          <tr>
            <th>Nama</th>
            <th>Email</th>
            <th>Skor</th>
            <th>Benar / Total</th>
            <th>Waktu</th>
          </tr>
        </thead>
        <tbody>
          {data.map((r, i) => (
            <tr key={i}>
              <td>{r.nama}</td>
              <td>{r.email}</td>
              <td>{r.skor}</td>
              <td>{r.benar} / {r.total_soal}</td>
              <td>{new Date(r.waktu).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}