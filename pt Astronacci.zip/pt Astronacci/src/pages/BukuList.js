import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function BukuList() {
  const [buku, setBuku] = useState([]);
  const [form, setForm] = useState({ judul: '', deskripsi: '', penulis: '', tahun: '' });

  const getData = async () => {
    const res = await axios.get('http://localhost:3000/api/buku');
    setBuku(res.data);
  };

  useEffect(() => { getData(); }, []);

  const handleSubmit = async e => {
    e.preventDefault();
    await axios.post('http://localhost:3000/api/buku', form);
    setForm({ judul: '', deskripsi: '', penulis: '', tahun: '' });
    getData();
  };

  const handleDelete = async id => {
    await axios.delete(`http://localhost:3000/api/buku/${id}`);
    getData();
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Daftar Buku</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Judul" value={form.judul} onChange={e => setForm({ ...form, judul: e.target.value })} />
        <input placeholder="Penulis" value={form.penulis} onChange={e => setForm({ ...form, penulis: e.target.value })} />
        <input placeholder="Tahun" value={form.tahun} onChange={e => setForm({ ...form, tahun: e.target.value })} />
        <textarea placeholder="Deskripsi" value={form.deskripsi} onChange={e => setForm({ ...form, deskripsi: e.target.value })} />
        <button type="submit">Tambah Buku</button>
      </form>

      <ul>
        {buku.map(b => (
          <li key={b.id}>
            <b>{b.judul}</b> - {b.penulis} ({b.tahun})<br />
            <i>{b.deskripsi}</i>
            <button onClick={() => handleDelete(b.id)}>Hapus</button>
          </li>
        ))}
      </ul>
    </div>
  );
}