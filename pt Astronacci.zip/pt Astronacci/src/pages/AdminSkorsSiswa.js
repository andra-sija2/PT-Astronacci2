import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Line } from 'react-chartjs-2';
import { Chart, LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend } from 'chart.js';

Chart.register(LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend);

export default function AdminSkorSiswa() {
  const [siswaList, setSiswaList] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [chartData, setChartData] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:3000/api/users/siswa').then(res => setSiswaList(res.data));
  }, []);

  useEffect(() => {
    if (!selectedId) return;
    axios.get(`http://localhost:3000/api/riwayat/skor/${selectedId}`).then(res => {
      const labels = res.data.map(r => new Date(r.waktu).toLocaleDateString());
      const skor = res.data.map(r => r.skor);
      setChartData({
        labels,
        datasets: [{
          label: 'Skor Latihan',
          data: skor,
          fill: false,
          borderColor: 'green',
          tension: 0.3
        }]
      });
    });
  }, [selectedId]);

  return (
    <div style={{ padding: 20 }}>
      <h2>Grafik Skor Siswa</h2>
      <select onChange={e => setSelectedId(e.target.value)} value={selectedId || ''}>
        <option value="" disabled>Pilih siswa</option>
        {siswaList.map(s => (
          <option key={s.id} value={s.id}>{s.nama} ({s.email})</option>
        ))}
      </select>

      {chartData && <Line data={chartData} />}
    </div>
  );
}