import React, { useEffect, useState } from 'react';

export default function AdminStatistik() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch('http://localhost/backend/api/statistik_semua_siswa.php')
      .then(res => res.json())
      .then(setData);
  }, []);

  const formatDurasi = detik => {
    const jam = Math.floor(detik / 3600);
    const menit = Math.floor((detik % 3600) / 60);
    return `${jam} jam ${menit} menit`;
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Statistik Semua Siswa</h2>
      <table border="1" cellPadding="8" cellSpacing="0">
        <thead>
          <tr>
            <th>Nama</th>
            <th>Email</th>
            <th>Chat AI</th>
            <th>Waktu Belajar</th>
          </tr>
        </thead>
        <tbody>
          {data.map(siswa => (
            <tr key={siswa.id}>
              <td>{siswa.nama}</td>
              <td>{siswa.email}</td>
              <td>{siswa.chat}</td>
              <td>{formatDurasi(siswa.durasi)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}