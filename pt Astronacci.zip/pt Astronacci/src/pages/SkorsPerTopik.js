import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Bar } from 'react-chartjs-2';
import { Chart, BarElement, CategoryScale, LinearScale, Tooltip, Legend } from 'chart.js';

Chart.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend);

export default function SkorPerTopik() {
  const [dataChart, setDataChart] = useState(null);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    axios.get(`http://localhost:3000/api/riwayat/skor-topik/${user.id}`).then(res => {
      const labels = res.data.map(d => d.topik);
      const skor = res.data.map(d => d.rata_rata);
      setDataChart({
        labels,
        datasets: [{
          label: 'Skor Rata-rata per Topik',
          data: skor,
          backgroundColor: 'rgba(75, 192, 192, 0.7)'
        }]
      });
    });
  }, []);

  return (
    <div style={{ padding: 20 }}>
      <h2>Statistik Skor per Topik</h2>
      {dataChart && <Bar data={dataChart} />}
    </div>
  );
}
