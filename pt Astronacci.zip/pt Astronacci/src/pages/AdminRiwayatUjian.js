import React, { useEffect, useState } from 'react';
import axios from 'axios';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export default function AdminRiwayatUjian() {
  const [riwayat, setRiwayat] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3000/api/admin/riwayat').then(res => {
      setRiwayat(res.data);
    });
  }, []);

  const exportPDF = () => {
    const doc = new jsPDF();
    doc.text("Laporan Hasil Ujian Semua Siswa", 14, 10);

    const tableData = riwayat.map((r, i) => [
      i + 1,
      r.nama,
      r.email,
      r.topik,
      r.total_soal,
      r.benar,
      r.skor,
      new Date(r.waktu).toLocaleString()
    ]);

    autoTable(doc, {
      head: [['No', 'Nama', 'Email', 'Topik', 'Total Soal', 'Benar', 'Skor', 'Waktu']],
      body: tableData,
      startY: 20,
      styles: { fontSize: 8 },
    });

    const [filter, setFilter] = useState({ topik: '', tanggal_awal: '', tanggal_akhir: '' });
    doc.save("Laporan_Ujian_Siswa.pdf");
  };

  const applyFilter = () => {
  const params = new URLSearchParams(filter);
  axios.get(`http://localhost:3000/api/admin/riwayat/filter?${params.toString()}`)
    .then(res => setRiwayat(res.data));
  };
  
  return (
    <div style={{ padding: 20 }}>
      <h2>Data Hasil Ujian Semua Siswa</h2>
      <button onClick={exportPDF}>📥 Export PDF</button>
      <h2>Data Hasil Ujian</h2>      
      <div style={{ marginBottom: 20 }}>
        <label>Topik: </label>
        <select value={filter.topik} onChange={e => setFilter({ ...filter, topik: e.target.value })}>
          <option value="">Semua</option>
          <option value="Matematika">Matematika</option>
          <option value="IPA">IPA</option>
          <option value="Bahasa">Bahasa</option>  
        </select>
        <label style={{ marginLeft: 10 }}>Tanggal Mulai:</label>
        <input type="date" value={filter.tanggal_awal} onChange={e => setFilter({ ...filter, tanggal_awal: e.target.value })} />
        <label style={{ marginLeft: 10 }}>Tanggal Akhir:</label>
        <input type="date" value={filter.tanggal_akhir} onChange={e => setFilter({ ...filter, tanggal_akhir: e.target.value })} />
        <button style={{ marginLeft: 10 }} onClick={applyFilter}>🔍 Cari</button>
        </div>
      <table border="1" cellPadding={5} style={{ marginTop: 20, width: '100%' }}>
        <thead>
          <tr>
            <th>No</th><th>Nama</th><th>Email</th><th>Topik</th><th>Total</th><th>Benar</th><th>Skor</th><th>Waktu</th>
          </tr>
        </thead>
        <tbody>
          {riwayat.map((r, i) => (
            <tr key={r.id}>
              <td>{i + 1}</td>
              <td>{r.nama}</td>
              <td>{r.email}</td>
              <td>{r.topik}</td>
              <td>{r.total_soal}</td>
              <td>{r.benar}</td>
              <td>{r.skor}</td>
              <td>{new Date(r.waktu).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}