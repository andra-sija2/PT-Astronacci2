import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function LatihanSoal() {
  const [soal, setSoal] = useState([]);
  const [jawaban, setJawaban] = useState({});
  const [nilai, setNilai] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:3000/api/soal').then(res => setSoal(res.data));
  }, []);

  const handleJawab = (id, pilihan) => {
    setJawaban(prev => ({ ...prev, [id]: pilihan }));
  };

  const nilaiAkhir = () => {
    let benar = 0;
    soal.forEach(s => {
      if (jawaban[s.id] === s.kunci_jawaban) benar++;
    });
    setNilai((benar / soal.length) * 100);
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Latihan Soal</h2>
      {soal.map((s, i) => (
        <div key={s.id} style={{ marginBottom: 20 }}>
          <p><b>{i + 1}. {s.pertanyaan}</b></p>
          {['A', 'B', 'C', 'D'].map(pil => (
            <label key={pil}>
              <input type="radio" name={`soal-${s.id}`} onChange={() => handleJawab(s.id, pil)} />
              {pil}. {s[`pilihan_${pil.toLowerCase()}`]}
              <br />
            </label>
          ))}
        </div>
      ))}
      <button onClick={nilaiAkhir}>Selesai</button>
      {nilai !== null && <p><b>Nilai kamu: {nilai}</b></p>}
    </div>
  );
}