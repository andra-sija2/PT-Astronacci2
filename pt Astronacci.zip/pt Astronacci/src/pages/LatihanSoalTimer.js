import React, { useEffect, useState } from 'react';
import axios from 'axios';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

const exportToPDF = () => {
  const doc = new jsPDF();
  doc.text(`Hasil Ujian - Topik: ${topik}`, 14, 10);
  doc.text(`Skor Akhir: ${nilai}`, 14, 18);

  const tableData = soal.map((s, i) => {
    return [
      i + 1,
      s.pertanyaan,
      jawaban[s.id] || '-',
      s.kunci_jawaban,
      jawaban[s.id] === s.kunci_jawaban ? '✔️' : '❌'
    ];
  });

  autoTable(doc, {
    head: [['No', 'Pertanyaan', 'Jawaban Anda', 'Kunci', 'Status']],
    body: tableData,
    startY: 25,
    styles: { fontSize: 8 },
    headStyles: { fillColor: [0, 102, 204] }
  });

  doc.save(`Hasil_Ujian_${topik}.pdf`);
};

export default function LatihanSoalTimer({ topik, mode = "latihan" }) {
  const [soal, setSoal] = useState([]);
  const [jawaban, setJawaban] = useState({});
  const [waktu, setWaktu] = useState(0);
  const [timerAktif, setTimerAktif] = useState(false);
  const [paused, setPaused] = useState(false);
  const [nilai, setNilai] = useState(null);
  const [indexSoal, setIndexSoal] = useState(0);

  const DURASI_TOPIK = {
    Matematika: 300,
    Bahasa: 600,
    IPA: 450,
  };

  useEffect(() => {
    axios.get('http://localhost:3000/api/soal').then(res => {
      const soalTopik = res.data.filter(s => s.topik === topik);
      setSoal(soalTopik);
      setWaktu(DURASI_TOPIK[topik] || 300);
      setTimerAktif(true);
    });
  }, [topik]);

  useEffect(() => {
    if (!timerAktif || paused || waktu <= 0) return;
    const t = setTimeout(() => setWaktu(prev => prev - 1), 1000);
    if (waktu === 1) handleSelesai();
    return () => clearTimeout(t);
  }, [waktu, paused, timerAktif]);

  const handleJawab = (id, pilihan) => {
    setJawaban(prev => ({ ...prev, [id]: pilihan }));
  };

  const handleSelesai = async () => {
    setTimerAktif(false);
    const benar = soal.filter(s => jawaban[s.id] === s.kunci_jawaban).length;
    const skor = Math.round((benar / soal.length) * 100);
    setNilai(skor);

    const user = JSON.parse(localStorage.getItem("user"));
    await axios.post('http://localhost:3000/api/riwayat', {
      user_id: user.id,
      total_soal: soal.length,
      benar,
      topik,
    });
  };

  const formatWaktu = (s) => {
    const m = Math.floor(s / 60);
    const d = s % 60;
    return `${m}:${d.toString().padStart(2, '0')}`;
  };

  const soalSekarang = soal[indexSoal];

  return (
    <div style={{ padding: 20 }}>
      <h2>Latihan Soal: {topik}</h2>
      <p><b>Waktu Tersisa:</b> {formatWaktu(waktu)}</p>

      {mode === 'latihan' && (
        <button onClick={() => setPaused(!paused)}>{paused ? 'Lanjutkan' : 'Pause'}</button>
      )}

      <hr />

      {soalSekarang && (
        <div>
          <p>{indexSoal + 1}. {soalSekarang.pertanyaan}</p>
          {['A', 'B', 'C', 'D'].map(pil => (
            <label key={pil}>
              <input
                type="radio"
                name={`soal-${soalSekarang.id}`}
                checked={jawaban[soalSekarang.id] === pil}
                onChange={() => handleJawab(soalSekarang.id, pil)}
                disabled={!timerAktif}
              />
              {pil}. {soalSekarang[`pilihan_${pil.toLowerCase()}`]}
              <br />
            </label>
          ))}
        </div>
      )}

      <div style={{ marginTop: 20 }}>
        <button onClick={() => setIndexSoal(indexSoal - 1)} disabled={indexSoal === 0}>⬅️ Sebelumnya</button>
        <button onClick={() => setIndexSoal(indexSoal + 1)} disabled={indexSoal === soal.length - 1}>Berikutnya ➡️</button>
      </div>

      <br />
      <button onClick={handleSelesai} disabled={!timerAktif}>Selesai Ujian</button>

      {nilai !== null && <h3>Skor Akhir: {nilai}</h3>}
      {nilai !== null && (
        <>
        <h3>Skor Akhir: {nilai}</h3>
        <button onClick={exportToPDF}>📥 Unduh Hasil PDF</button>
        </>
      )}
    </div>
  );
}