import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function JadwalUjianPage({ topik }) {
  const [aktif, setAktif] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get(`http://localhost:3000/api/ujian/jadwal/${topik}`).then(res => {
      setAktif(res.data.aktif);
      setLoading(false);
    });
  }, [topik]);

  if (loading) return <p>Memeriksa jadwal ujian...</p>;

  return (
    <div style={{ padding: 20 }}>
      <h2>Ujian Topik: {topik}</h2>
      {aktif ? (
        <button onClick={() => window.location.href = `/ujian/${topik}`}>
          Mulai Ujian Sekarang
        </button>
      ) : (
        <p style={{ color: 'red' }}>Jadwal ujian belum aktif atau sudah berakhir.</p>
      )}
    </div>
  );
}