import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import BukuList from './pages/BukuList';
import LatihanSoal from './pages/LatihanSoal';
import AdminRiwayat from './pages/AdminRiwayat';
import RequireRole from './components/RequireRole';
import SkorChart from './pages/SkorChart';
import AdminSkorSiswa from './pages/AdminSkorSiswa';
import SkorPerTopik from './pages/SkorPerTopik';
import LatihanSoalTimer from './pages/LatihanSoalTimer';
import JadwalUjianPage from './pages/JadwalUjianPage';
import AdminRiwayatUjian from './pages/AdminRiwayatUjian';


function App() {
  return (
    <Router>
      <Routes>
        {/* Umum */}
        <Route path="/buku" element={<BukuList />} />
        <Route path="/soal" element={
          <RequireRole allowed={['siswa']}>
            <LatihanSoal />
          </RequireRole>
        } />
        
        {/* Hanya Admin */}
        <Route path="/riwayat" element={
          <RequireRole allowed={['admin']}>
            <AdminRiwayat />
          </RequireRole>
        } />
        <RequireRole allowed={['siswa']}>
            <SkorChart />
            </RequireRole>
      </Routes>
      <Route path="/admin-skor" element={
        <RequireRole allowed={['admin']}>
            <AdminSkorSiswa />
        </RequireRole>
        } />
       <Route path="/skor-topik" element={
        <RequireRole allowed={['siswa', 'admin']}>
            <SkorPerTopik />
        </RequireRole>
        } />
        <Route path="/soal/:topik" element={
            <RequireRole allowed={['siswa']}>
                <LatihanSoalTimer topik={decodeURIComponent(window.location.pathname.split("/").pop())} />
            </RequireRole>
        } />
        <Route path="/ujian/:topik" element={
            <RequireRole allowed={['siswa']}>
                <LatihanSoalTimer topik={decodeURIComponent(window.location.pathname.split("/").pop())} mode="ujian" />
            </RequireRole>
        } />
        <Route path="/jadwal-ujian/:topik" element={
            <RequireRole allowed={['siswa']}>
                <JadwalUjianPage topik={decodeURIComponent(window.location.pathname.split("/").pop())} />
            </RequireRole>
        } />
        <Route path="/admin/riwayat" element={
            <RequireRole allowed={['admin']}>
                <AdminRiwayatUjian />
                </RequireRole>
            } />
    </Router>
  );
}