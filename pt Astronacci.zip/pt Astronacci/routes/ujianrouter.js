const express = require('express');
const router = express.Router();
const ujian = require('../controllers/ujianController');

router.get('/jadwal/:topik', ujian.getAktifUjian);

module.exports = router;