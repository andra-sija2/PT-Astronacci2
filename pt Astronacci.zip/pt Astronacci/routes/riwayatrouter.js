const express = require('express');
const router = express.Router();
const riwayat = require('../controllers/riwayatController');

router.post('/', riwayat.simpanRiwayat);
router.get('/', riwayat.getRiwayatAll);
router.get('/skor-topik/:id', riwayat.getSkorByUserGroupedByTopik);

module.exports = router;