const express = require('express');
const router = express.Router();
const soal = require('../controllers/soalController');

router.get('/', soal.getAll);
router.post('/', soal.create);
router.delete('/:id', soal.delete);

module.exports = router;