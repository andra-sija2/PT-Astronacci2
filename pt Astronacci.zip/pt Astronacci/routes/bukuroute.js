const express = require('express');
const router = express.Router();
const buku = require('../controllers/bukuController');

router.get('/', buku.getAll);
router.post('/', buku.create);
router.put('/:id', buku.update);
router.delete('/:id', buku.delete);

module.exports = router;