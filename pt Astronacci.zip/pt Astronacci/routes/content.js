const express = require('express');
const router = express.Router();
const { ensureAuthenticated } = require('../middlewares/authMiddleware');
const { limitContent } = require('../middlewares/accessLimiter');
const { getArticles, getVideos } = require('../controllers/contentController');
const AccessLog = require('../models/Accesslog');
const Article = require('../models/Article');
const Video = require('../models/Video');
const { checkAccessLimit } = require('../middlewares/limitAccessPerUser');
const content = require('../controllers/contentController');

router.get('/dashboard', content.dashboard);

module.exports = router;

router.get('/articles/:id', ensureAuthenticated, checkAccessLimit('article'), async (req, res) => {
  const article = await Article.findById(req.params.id);

  await AccessLog.create({
    userId: req.user._id,
    contentType: 'article',
    contentId: article._id
  });

  res.render('article-detail', { article });
});

router.get('/videos/:id', ensureAuthenticated, checkAccessLimit('video'), async (req, res) => {
  const video = await Video.findById(req.params.id);

  await AccessLog.create({
    userId: req.user._id,
    contentType: 'video',
    contentId: video._id
  });

  res.render('video-detail', { video });
});

router.get('/articles', ensureAuthenticated, limitContent('article'), getArticles);
router.get('/videos', ensureAuthenticated, limitContent('video'), getVideos);
router.get('/dashboard', cekExpired, content.dashboard);

module.exports = router;