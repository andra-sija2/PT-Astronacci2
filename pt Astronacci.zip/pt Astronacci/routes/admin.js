const express = require('express');
const router = express.Router();
const { isAdmin } = require('../middlewares/roleMiddleware');
const Article = require('../models/Article');
const Video = require('../models/Video');

router.get('/admin/articles/new', isAdmin, (req, res) => {
  res.render('admin-add-article');
});

router.post('/admin/articles', isAdmin, async (req, res) => {
  const { title, content } = req.body;
  await Article.create({ title, content });
  res.redirect('/articles');
});

router.get('/admin/videos/new', isAdmin, (req, res) => {
  res.render('admin-add-video');
});

router.get('/ujian/hasil', adminOnly, admin.hasilUjian);

router.post('/ujian/hasil/filter', adminOnly, admin.filterHasilUjian);

router.get('/ujian/grafik', adminOnly, admin.grafikUjian);

router.post('/admin/videos', isAdmin, async (req, res) => {
  const { title, url } = req.body;
  await Video.create({ title, url });
  res.redirect('/videos');
});

router.get('/riwayat/filter', admin.getRiwayatFiltered);

router.get('/riwayat', admin.viewRiwayat);
router.post('/riwayat/filter', admin.filterRiwayat); 

module.exports = router;
