const express = require('express');
const passport = require('passport');
const router = express.Router();
const User = require('../models/user');
const auth = require('../controllers/authController');

router.get('/register', auth.showRegister);
router.post('/register', auth.handleRegister);
router.get('/login', auth.showLogin);
router.post('/login', auth.handleLogin);
router.get('/logout', auth.logout);

module.exports = router;

router.get('/login', (req, res) => res.render('login'));
router.get('/register', (req, res) => res.render('register'));

router.post('/register', async (req, res) => {
  const { name, email, password, membership } = req.body;
  const user = await User.create({ name, email, password, membership });
  res.redirect('/login');
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email, password }); // Plaintext only for demo!
  if (user) {
    req.login(user, err => {
      if (err) return res.redirect('/login');
      res.redirect('/dashboard');
    });
  } else {
    res.redirect('/login');
  }
});

router.get('/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));
router.get('/auth/google/callback', passport.authenticate('google', { failureRedirect: '/login' }), (req, res) => {
  res.redirect('/dashboard');
});

router.get('/auth/facebook', passport.authenticate('facebook', { scope: ['email'] }));
router.get('/auth/facebook/callback', passport.authenticate('facebook', { failureRedirect: '/login' }), (req, res) => {
  res.redirect('/dashboard');
});

router.get('/logout', (req, res) => {
  req.logout(() => {
    res.redirect('/login');
  });
});

module.exports = router;
